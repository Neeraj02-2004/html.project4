# Ping Pong using Java

```--module-path "" --add-modules javafx.controls,javafx.fxml```
